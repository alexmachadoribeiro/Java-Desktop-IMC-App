package br.com.imc;

public interface UsuarioInterface {
	public double calcularIMC();
	public String mostrarResultado(double imc);
}
